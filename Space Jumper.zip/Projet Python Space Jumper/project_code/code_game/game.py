import random
import pygame
import math
import sys
from project_code.code_menu import menu
from project_code.code_game import class_bonus, class_opponent, class_player, function_game, class_obstacle, class_sound

# Les imports importent les modules et les classes nécessaires pour le jeu.

nb_obstacle = 0
score_temp = 0
score = 0
health = 3
speed = 1
text_col = (255, 255, 255)
width_screen = pygame.display.Info().current_w
height_screen = pygame.display.Info().current_h
font = pygame.font.SysFont("arial black", 40).render
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
# Ce sont des variables utilisées dans le jeu, telles que le nombre d'obstacles,
# le meilleur score, le score temporaire, le score actuel, la santé, la vitesse et l'écran du jeu.
while True:
    change_jump_gravity = 40
    # C'est la boucle principale du jeu qui s'exécute en continu jusqu'à ce que le jeu se termine.
    screen.blit(pygame.image.load("./img_game/bg.png").convert(), (0, 0))
    # Cela affiche l'image de fond du jeu sur l'écran.
    walls = class_obstacle.random_list_obstacle(nb_obstacle)
    player = class_player.Player(speed)
    best_score = function_game.load_game()
    bonus_position = (random.randint(350, pygame.display.Info().current_w),
                      random.randint(0, pygame.display.Info().current_h))
    game_passed = False
    if nb_obstacle % 5 == 4 and not game_passed:
        bonus = class_bonus.Bonus(bonus_position, "./img_game/super_bonus.png")
    else:
        bonus = class_bonus.Bonus(bonus_position, "./img_game/bonus_malus.png")
    clock = pygame.time.Clock()
    nb_obstacle += 1
    score_temp += 1
    speed *= 1.1
    bonus.draw(screen)
    list_opponent = []
    nb_opponent = int((random.randint(1, nb_obstacle))/2)
    if nb_opponent == 0:
        nb_opponent = 1
    for r in range(nb_opponent):
        list_opponent.append(class_opponent.Opponent())
    # Ces lignes initialisent les objets du jeu tels que les obstacles, le joueur, le bonus, l'horloge,
    # les adversaires, etc.
    while not player.player_x_change > pygame.display.Info().current_w:
        # C'est une boucle qui s'exécute tant que la position horizontale du joueur
        # est inférieure à la largeur de l'écran.
        clock.tick(60)
        # Cela limite la vitesse du jeu à 60 images par seconde.
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                function_game.save_game(best_score)
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    menu.menu("pause")
                    break
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    score += 20 * score_temp
                    player.speedY += change_jump_gravity
                    player.on_ground = False
        # Ces lignes gèrent les événements du jeu tels que les mouvements du joueur et la sortie du jeu.
        if player.move() or function_game.check_collisions(walls, player, list_opponent):
            if health > 1:
                class_sound.Sound().damage.play()
            health -= 1
            if score >= 500:
                score -= 500
            bonus_position = (random.randint(350, pygame.display.Info().current_w),
                              random.randint(0, pygame.display.Info().current_h))
            bonus = class_bonus.Bonus(bonus_position, "./img_game/bonus_malus.png")
            player.player_x_change = 100
            player.player_y_change = 500
            player.speedX = 50 * math.cos(math.radians(20)) * player.player_speed
            player.speedY = 10 * math.sin(math.radians(20))
            if health == 0:
                class_sound.Sound().dead.play()
                best_score = function_game.update_best_score(score, best_score)
                function_game.save_game(best_score)
                menu.game_over(str(score))
        # Ces lignes vérifient les collisions entre le joueur et les obstacles ou les adversaires.
        # Si une collision est détectée, la santé du joueur est réduite,
        # le score est ajusté et le joueur est réinitialisé.
        # Si la santé atteint 0, le meilleur score est mis à jour,
        # le jeu est sauvegardé et l'écran de fin de partie est affiché.
        if function_game.check_collision_bonus(player, bonus):
            class_sound.Sound().bonus.play()
            bonus_position = (100000, random.randint(0, pygame.display.Info().current_h))
            bonus.rect.center = bonus_position
            if nb_obstacle % 5 == 0 and not game_passed:
                health = 5
                game_passed = True
            else:
                alea = random.randint(0, 2)
                if alea == 1:
                    if health < 3:
                        health += 1
                    else:
                        score_temp *= 2
                if alea == 0:
                    player.gravity *= 2
                if alea == 2:
                    player.gravity = -player.gravity
                    change_jump_gravity = -change_jump_gravity
                function_game.save_game(best_score)
        screen.blit(pygame.image.load("./img_game/bg.png").convert(), (0, 0))
        # Ces lignes vérifient si le joueur entre en collision avec le bonus. Si c'est le cas,
        # la santé ou le score temporaire est augmenté, le bonus est déplacé à une nouvelle position aléatoire
        # et le jeu est sauvegardé.
        for x in range(len(walls)):
            walls[x].draw(screen)
        for y in range(len(list_opponent)):
            list_opponent[y].move()
            list_opponent[y].draw(screen)
        player.draw(screen)
        bonus.draw(screen)
        screen.blit(font("Score :", True, text_col), (80, 60))
        screen.blit(font(str(score), True, text_col), (280, 60))
        screen.blit(font("Best Score :", True, text_col), (80, 10))
        screen.blit(font(str(best_score), True, text_col), (370, 10))
        screen.blit(font("Life :", True, text_col), (480, 50))
        for i in range(health):
            img = pygame.image.load("./img_game/heart.png")
            img_heart = pygame.transform.scale(img, (35, 35))
            screen.blit(img_heart, (610 + i * 40, 67))
        screen.blit(font("Level :", True, text_col), (1200, 50))
        screen.blit(font(str(nb_obstacle), True, text_col), (1400, 50))
        pygame.display.update()
        # Ces lignes dessinent les objets du jeu tels que les obstacles, les adversaires, le joueur, le bonus,
        # le score, la santé, etc., sur l'écran du jeu.
        # La boucle principale continue à exécuter ces étapes tant que le jeu est en cours.
