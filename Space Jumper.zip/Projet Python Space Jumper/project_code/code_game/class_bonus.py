import pygame

# Importe la bibliothèque Pygame


class Bonus:
    # Le code représente une classe Bonus qui crée et affiche un bonus dans un jeu à l'aide de la bibliothèque Pygame
    def __init__(self, position, img):
        # Constructeur de la classe Bonus, prend une position en paramètre
        self.image = pygame.transform.scale(pygame.image.load(img), (50, 50))
        # Charge l'image du bonus depuis le fichier "bonus.png" et la redimensionne à 50x50 pixels
        self.rect = self.image.get_rect()
        # Crée un rectangle correspondant aux dimensions de l'image du bonus
        self.rect.center = position
        # Positionne le centre du rectangle du bonus sur la position donnée en paramètre

    def draw(self, screen):
        # Méthode pour afficher le bonus à l'écran
        screen.blit(self.image, self.rect)
        # Dessine l'image du bonus sur l'écran aux coordonnées définies par le rectangle
