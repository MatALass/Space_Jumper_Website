import pygame
# Importe le module pygame, qui est une bibliothèque utilisée pour le développement de jeux en Python.


class Sound:
    # Définit une classe appelée Sound. Une classe est une structure qui peut contenir des variables
    # (appelées attributs) et des fonctions (appelées méthodes) liées à cette classe.
    def __init__(self):
        # Définit une méthode spéciale __init__ qui est exécutée automatiquement lorsqu'un nouvel objet de la classe
        # Sound est créé. Cela s'appelle le constructeur de la classe.
        self.dead = pygame.mixer.Sound('./music_game/dead.mp3')
        # Charge le fichier audio du son "dead" lorsque les points de vie atteignent 0.
        self.damage = pygame.mixer.Sound('./music_game/damage.mp3')
        # Charge le fichier audio du son "damage" lorsque le joueur subit des dégâts.
        self.click = pygame.mixer.Sound('./music_game/click.mp3')
        # Charge le fichier audio du son "click" lorsque le joueur appuie sur un bouton.
        self.jump = pygame.mixer.Sound('./music_game/jump.mp3')
        # Charge le fichier audio du son "jump".
        self.bonus = pygame.mixer.Sound('./music_game/bonus.mp3')
        # Charge le fichier audio du son "bonus".
        self.level = pygame.mixer.Sound('./music_game/level.mp3')
        # Charge le fichier audio du son "level".
        self.jump.set_volume(0.05)
        # Définit le volume du son "jump" à 0.05 (5% du volume maximal).
        self.damage.set_volume(0.2)
        # Définit le volume du son "damage" à 0.2 (20% du volume maximal).
        self.dead.set_volume(0.1)
        # Définit le volume du son "dead" à 0.1 (10% du volume maximal).
