# importation du module pygame
import pygame
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)


# La fonction update_best_score met à jour le meilleur score d'un jeu
# en comparant le score actuel avec le meilleur score existant.
def update_best_score(score_game, best_score_game):
    # Vérifie si le score actuel est supérieur au meilleur score existant
    if score_game > best_score_game:
        # Si c'est le cas, met à jour le meilleur score avec le score actuel
        best_score_game = score_game
    # Retourne le meilleur score mis à jour
    return best_score_game


# La fonction save_game enregistre le meilleur score d'un jeu dans un fichier texte.
def save_game(best_score_game):
    # Ouvre le fichier "score.txt" en mode écriture
    with open("./score_game/score.txt", "w") as file:
        # Écrit la valeur du meilleur score convertie en chaîne de caractères dans le fichier
        file.write(str(best_score_game))


# La fonction load_game charge le meilleur score d'un jeu à partir d'un fichier texte.
def load_game():
    try:
        # Tente d'ouvrir le fichier "score.txt" en mode lecture
        with open("./score_game/score.txt", "r") as file:
            # Lit le contenu du fichier et convertit en entier
            best_score_game = int(file.read())
    except (FileNotFoundError, IndexError, ValueError):
        # Si une des exceptions suivantes se produit :
        # - FileNotFoundError : si le fichier n'est pas trouvé
        # - IndexError : si une erreur d'index se produit lors de la lecture
        # - ValueError : si une erreur de conversion en entier se produit lors de la lecture
        # Dans ces cas, le meilleur score du jeu est défini à 0
        best_score_game = 0
    # Retourne le meilleur score du jeu (soit la valeur lue à partir du fichier, soit 0 si une exception s'est produite)
    return best_score_game


# La fonction check_collision_bonus vérifie s'il y a une collision entre le joueur et le bonus dans un jeu.
def check_collision_bonus(player_game, bonus_game):
    # Crée un rectangle représentant la zone occupée par le joueur
    player_rect = pygame.Rect(player_game.player_x_change, player_game.player_y_change,
                              player_game.image.get_width(), player_game.image.get_height())
    # Crée un rectangle représentant la zone occupée par le bonus
    bonus_rect = pygame.Rect(bonus_game.rect.x, bonus_game.rect.y,
                             bonus_game.image.get_width(), bonus_game.image.get_height())
    # Vérifie s'il y a une collision entre les deux rectangles
    if player_rect.colliderect(bonus_rect):
        # Si une collision est détectée, retourne True
        return True
    # Si aucune collision n'est détectée, retourne False
    return False


# La fonction check_collisions vérifie s'il y a une collision entre
# le joueur et certains objets du jeu (obstacles ou adversaires).
def check_collisions(list_object_game, player_game, list_enemy_game):
    # Parcourt la liste des objets du jeu
    for u in range(len(list_object_game)):
        # Crée un rectangle représentant la zone occupée par le joueur
        player_rect = pygame.Rect(player_game.player_x_change, player_game.player_y_change,
                                  player_game.image.get_width(), player_game.image.get_height())
        # Crée un rectangle représentant la zone occupée par l'obstacle en cours de vérification
        obstacle_rect = pygame.Rect(list_object_game[u].obstacle_x_change, list_object_game[u].obstacle_y_change,
                                    list_object_game[u].image.get_width(), list_object_game[u].image.get_height())
        if player_rect.colliderect(obstacle_rect):
            # Si une collision est détectée, retourne True
            return True
    for z in range(len(list_enemy_game)):
        # Crée un rectangle représentant la zone occupée par le joueur
        player_rect = pygame.Rect(player_game.player_x_change, player_game.player_y_change,
                                  player_game.image.get_width(), player_game.image.get_height())
        # Si l'objet est un adversaire
        foe_rect = pygame.Rect(list_enemy_game[z].opponent_x, list_enemy_game[z].opponent_y,
                               list_enemy_game[z].image.get_width(), list_enemy_game[z].image.get_height())
        # Vérifie s'il y a une collision entre le joueur et l'objet en cours de vérification
        if player_rect.colliderect(foe_rect):
            # Si une collision est détectée, retourne True
            return True
    # Si aucune collision n'est détectée, retourne False
    return False
