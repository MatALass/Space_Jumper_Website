import random
import math
import pygame

# Importe les bibliothèques random, math et Pygame


class Opponent:
    # Le code présente une classe Opponent qui représente un adversaire dans un jeu.
    def __init__(self):
        # Constructeur de la classe Opponent
        self.opponent_x = 1800
        # Position x de l'adversaire
        self.opponent_y = random.randint(0, 800)
        # Position y de l'adversaire, générée aléatoirement entre 0 et 800
        self.speedX = 50 * math.cos(math.radians(45))
        # Vitesse horizontale de l'adversaire, calculée en fonction de l'angle de 45 degrés
        self.speedY = 10 * math.sin(math.radians(45))
        # Vitesse verticale de l'adversaire, calculée en fonction de l'angle de 45 degrés
        self.interval = 0.09
        # Intervalle de temps utilisé pour les calculs de mouvement
        self.gravity = 9.8
        # Gravité appliquée à l'adversaire
        scaled_width = pygame.image.load("./img_game/opponent.png").get_width() * 0.5
        # Largeur de l'image de l'adversaire redimensionnée à 50% de sa taille originale
        scaled_height = pygame.image.load("./img_game/opponent.png").get_height() * 0.5
        # Hauteur de l'image de l'adversaire redimensionnée à 50% de sa taille originale
        self.image = pygame.transform.scale(pygame.image.load("./img_game/opponent.png"), (scaled_width, scaled_height))
        # Charge et redimensionne l'image de l'adversaire à l'aide des dimensions calculées

    def draw(self, window):
        # Méthode pour afficher l'adversaire à l'écran
        window.blit(self.image, (self.opponent_x, self.opponent_y))
        # Dessine l'image de l'adversaire aux coordonnées définies par sa position x et y

    def move(self):
        # Méthode pour déplacer l'adversaire
        self.opponent_x -= self.speedX * math.cos(math.radians(45)) * self.interval
        # Met à jour la position horizontale de l'adversaire en fonction de sa vitesse horizontale
        self.opponent_y -= self.interval * (self.speedY - (self.gravity * self.interval))
        # Met à jour la position verticale de l'adversaire en fonction de sa vitesse verticale et de la gravité
        self.speedY += -self.gravity * self.interval
        # Met à jour la vitesse verticale de l'adversaire en fonction de la gravité
        if self.speedY < -74:
            # Si la vitesse verticale est inférieure à -74 (valeur arbitraire)
            self.speedY += 150
            # Ajoute une augmentation de la vitesse verticale pour simuler un rebond ou un effet de saut
