# Importation des modules pygame et math
import pygame
import math


# Définition de la classe Player pour afficher l'avion dans le jeu et gérer son mouvement
class Player:
    # Constructeur de la classe Player qui prend en paramètre la vitesse de l'avion
    def __init__(self, speed_game):
        # Initialisation des attributs de la classe Player
        self.player_speed = speed_game
        # Vitesse de l'avion, peut être modifiée lorsque le joueur monte de niveau
        self.player_x_change = 100
        # Position x de l'avion
        self.player_y_change = 500
        # Position y de l'avion
        self.speedX = 50 * math.cos(math.radians(20)) * self.player_speed
        # Vitesse horizontale de l'avion, calculée en fonction de l'angle de 20 degrés et de la vitesse du joueur
        self.speedY = 10 * math.sin(math.radians(20))
        # Vitesse verticale de l'avion, calculée en fonction de l'angle de 20 degrés
        self.interval = 0.09
        # Intervalle de temps utilisé pour les calculs de mouvement
        self.gravity = 9.8
        # Gravité appliquée à l'avion
        self.image = pygame.image.load("./img_game/player.png")
        # Chargement de l'image de l'avion

    # Méthode pour afficher l'avion à l'écran
    def draw(self, window):
        window.blit(self.image, (self.player_x_change, self.player_y_change))
        # Dessine l'image de l'avion aux coordonnées définies par sa position x et y

    # Méthode pour déplacer l'avion
    def move(self):
        self.player_x_change += self.speedX * math.cos(math.radians(45)) * self.interval
        # Met à jour la position horizontale de l'avion en fonction de sa vitesse horizontale
        self.player_y_change -= self.interval * (self.speedY - (self.gravity * self.interval))
        # Met à jour la position verticale de l'avion en fonction de sa vitesse verticale et de la gravité
        self.speedY += -self.gravity * self.interval
        # Met à jour la vitesse verticale de l'avion en fonction de la gravité

        # Vérifie si l'avion a atteint les limites supérieure ou inférieure de l'écran
        if self.player_y_change >= pygame.display.Info().current_h or self.player_y_change <= 0:
            return True
            # Retourne True si l'avion dépasse les limites
        return False
        # Retourne False si l'avion est toujours dans les limites de l'écran
