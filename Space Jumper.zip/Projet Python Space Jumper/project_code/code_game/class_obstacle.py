import random
import pygame
# Importe les bibliothèques random et Pygame


def random_list_obstacle(nombre_obstacle):
    # Fonction pour générer une liste d'obstacles aléatoires
    list_obstacle_game = []
    # Crée une liste vide pour stocker les obstacles
    for j in range(random.randint(nombre_obstacle * 3, nombre_obstacle * 3 + 4)):
        # Génère un nombre aléatoire d'obstacles compris entre nombre_obstacle*5 et nombre_obstacle*5+4
        list_obstacle_game.append(Obstacle())
        # Ajoute un nouvel obstacle à la liste des obstacles
    return list_obstacle_game
    # Retourne la liste des obstacles générés aléatoirement


class Obstacle:
    # Le code représente une classe Obstacle pour générer des obstacles aléatoires
    # dans un jeu à l 'aide de la bibliothèque Pygame.
    def __init__(self):
        # Constructeur de la classe Obstacle
        self.obstacle_x_change = random.randint(350, pygame.display.Info().current_w - 10)
        # Position x de l'obstacle, générée aléatoirement entre 300 et la largeur de l'écran - 10
        self.obstacle_y_change = random.randint(100, 800)
        # Position y de l'obstacle, générée aléatoirement entre 100 et 800
        self.scale = random.uniform(0.5, 1.5)
        # Échelle de l'obstacle, générée aléatoirement entre 0.5 et 1.5
        list_img_asteroid = [(pygame.image.load("./img_game/ASTEROID_1.jpg")),
                             (pygame.image.load("./img_game/ASTEROID_2.png"))]
        # Liste des images d'astéroïdes
        random_asteroid = random.randint(0, 1)
        # Sélectionne aléatoirement un astéroïde dans la liste
        self.scale = random.uniform(0.5, 2)
        # Réassigne une nouvelle échelle de l'obstacle, générée aléatoirement entre 0.5 et 2
        scaled_width = int(list_img_asteroid[random_asteroid].get_width() * self.scale)
        # Calcule la nouvelle largeur de l'image de l'obstacle en fonction de l'échelle
        scaled_height = int(list_img_asteroid[random_asteroid].get_height() * self.scale)
        # Calcule la nouvelle hauteur de l'image de l'obstacle en fonction de l'échelle
        self.image = pygame.transform.scale(list_img_asteroid[random_asteroid], (scaled_width, scaled_height))
        # Redimensionne l'image de l'obstacle à l'aide de la nouvelle largeur et hauteur calculées

    def draw(self, screen):
        # Méthode pour afficher l'obstacle à l'écran
        screen.blit(self.image, (self.obstacle_x_change, self.obstacle_y_change))
        # Dessine l'image de l'obstacle aux coordonnées définies par sa position x et y
