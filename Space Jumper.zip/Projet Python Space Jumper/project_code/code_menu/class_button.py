import pygame
# Importe le module pygame qui est utilisé pour créer des jeux et des applications graphiques.


class Button:
    # Définit une classe appelée Button pour représenter un bouton.
    def __init__(self, x, y, image, scale):
        # Définit le constructeur de la classe Button qui est appelé lorsqu'un nouvel objet Button est créé.
        # Il prend en paramètres les coordonnées x et y du bouton, une image représentant le bouton
        # et une échelle de mise à l'échelle de l'image.
        width = image.get_width()
        height = image.get_height()
        # Obtient la largeur et la hauteur de l'image du bouton.
        self.image = pygame.transform.scale(image, (int(width * scale), int(height * scale)))
        # Met à l'échelle l'image du bouton en utilisant la fonction scale du module pygame.transform.
        # La nouvelle taille est calculée en multipliant la largeur et la hauteur par l'échelle spécifiée.
        self.rect = self.image.get_rect()
        # Obtient le rectangle englobant de l'image mise à l'échelle.
        self.rect.topleft = (x, y)
        # Définit les coordonnées du coin supérieur gauche du rectangle pour placer le bouton à la position spécifiée.
        self.clicked = False
        # Initialise la variable clicked à False, indiquant que le bouton n'a pas été cliqué.

    def draw(self, surface):
        # Définit une méthode draw qui prend en paramètre une surface sur laquelle dessiner le bouton.
        action = False
        pos = pygame.mouse.get_pos()
        # Initialise la variable action à False et obtient la position actuelle de la souris.
        if self.rect.collidepoint(pos):
            # Vérifie si la position de la souris est à l'intérieur du rectangle
            # du bouton en utilisant la méthode collidepoint du rectangle.
            if pygame.mouse.get_pressed()[0] == 1 and not self.clicked:
                # Vérifie si le bouton de la souris (clic gauche) est enfoncé et si le bouton
                # n'a pas déjà été cliqué précédemment.
                self.clicked = True
                action = True
                # Marque le bouton comme cliqué en définissant clicked à True et indique qu'une action a été
                # effectuée en définissant action à True.
        if pygame.mouse.get_pressed()[0] == 0:
            # Vérifie si le bouton de la souris a été relâché (n'est plus enfoncé).
            self.clicked = False
            # Réinitialise clicked à False pour indiquer que le bouton n'est plus cliqué.
        surface.blit(self.image, (self.rect.x, self.rect.y))
        # Dessine l'image du bouton sur la surface à la position spécifiée par les coordonnées du rectangle du bouton.
        return action
        # Retourne la valeur de action qui indique si le bouton a été cliqué ou non.
