import pygame
import sys
from project_code.code_menu import class_button
from project_code.code_game import class_sound
# Importe les modules nécessaires.
pygame.init()
# Initialise le module pygame.
pygame.mixer_music.load('./music_game/game.mp3')
pygame.mixer.music.play(-1)

pygame.display.set_caption("Pause")
# Définit le titre de la fenêtre pygame.
screen = pygame.display.set_mode((pygame.display.Info().current_w, pygame.display.Info().current_h))
# Crée une fenêtre avec les dimensions de l'écran.
screen_button = (pygame.display.Info().current_w-158*2)/2
# Calcule la position horizontale des boutons sur l'écran.


def draw_text(text, text_col, x, y):
    # Définit une fonction pour dessiner du texte à l'écran.
    img = pygame.font.SysFont("arial black", 40).render(text, True, text_col)
    screen.blit(img, (x, y))


def game_over(score):
    # Définit une fonction game_over qui affiche l'écran de fin de jeu.
    run_game = True
    # Initialise une variable pour exécuter la boucle du jeu.
    screen.blit(pygame.image.load("./img_game/bg.png").convert(), (0, 0))
    # Charge et dessine l'image de fond à l'écran.
    img = pygame.image.load("./img_game/game_over.png")
    img = pygame.transform.scale(img, (int(img.get_width() * 4), int(img.get_height() * 4)))
    screen.blit(img, ((pygame.display.Info().current_w - (124*4)) / 2, (pygame.display.Info().current_h - (375*2)) / 2))
    # Charge l'image de fin de jeu, la met à l'échelle et la dessine au centre de l'écran.
    new_menu_button = class_button.Button(screen_button, 550, pygame.image.load("./img_button/MENU.png")
                                          .convert_alpha(), 2)
    new_restart_button = class_button.Button(screen_button, 400, pygame.image.load('./img_button/RESTART.png')
                                             .convert_alpha(), 2)
    quit_button = class_button.Button(screen_button, 700, pygame.image.load("./img_button/QUIT.png")
                                      .convert_alpha(), 2)
    # Crée des objets de la classe Button pour les boutons de menu.
    text = "Score : " + score
    # Définit le texte à afficher avec le score.
    while run_game:
        # Démarre la boucle principale du jeu.
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        # Gère les événements pygame, tels que la fermeture de la fenêtre.

        draw_text(text, (255, 255, 255), (pygame.display.Info().current_w - 775-(len(text)*10)), 320)
        # Dessine le texte du score à l'écran.
        if new_restart_button.draw(screen):
            class_sound.Sound().click.play()
            exec(open("./project_code/code_game/game.py").read())
        # Si le bouton de redémarrage est cliqué, exécute le fichier game.py pour recommencer le jeu.
        elif new_menu_button.draw(screen):
            class_sound.Sound().click.play()
            menu("menu")
        # Si le bouton de menu est cliqué, appelle la fonction menu avec l'argument "menu".
        elif quit_button.draw(screen):
            class_sound.Sound().click.play()
            pygame.quit()
            sys.exit()
        # Si le bouton de quitter est cliqué, ferme le jeu.
        pygame.display.update()
        # Met à jour l'affichage de l'écran.


def menu(menu_game="menu"):
    # Définit une fonction menu qui gère l'écran de menu.
    run_game = True
    # Initialise une variable pour exécuter la boucle du menu.
    resume_button = class_button.Button(screen_button, 400, pygame.image.load("./img_button/RESUME.png")
                                        .convert_alpha(), 2)
    play_button = class_button.Button(screen_button, 400, pygame.image.load("./img_button/PLAY.png")
                                      .convert_alpha(), 2)
    settings_button = class_button.Button(screen_button, 550, pygame.image.load("./img_button/SETTINGS.png")
                                          .convert_alpha(), 2)
    credits_button = class_button.Button(screen_button, 460, pygame.image.load('./img_button/CREDITS.png')
                                         .convert_alpha(), 2)
    rules_button = class_button.Button(screen_button, 160, pygame.image.load('./img_button/RULES.png')
                                       .convert_alpha(), 2)
    hotkeys_button = class_button.Button(screen_button, 310, pygame.image.load('./img_button/HOTKEYS.png')
                                         .convert_alpha(), 2)
    back_button = class_button.Button(screen_button, 610, pygame.image.load('./img_button/BACK.png')
                                      .convert_alpha(), 2)
    quit_button = class_button.Button(screen_button, 700, pygame.image.load("./img_button/QUIT.png")
                                      .convert_alpha(), 2)
    # Crée des objets de la classe Button pour les différents boutons du menu.
    while run_game:
        screen.blit(pygame.image.load("./img_game/bg.png").convert(), (0, 0))
        # Charge et dessine l'image de fond du menu.
        if menu_game == "pause":
            screen.blit(pygame.image.load("./img_game/titre.png").convert(), (540, 75))
            if resume_button.draw(screen):
                class_sound.Sound().click.play()
                run_game = False
            elif settings_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "settings"
            elif quit_button.draw(screen):
                class_sound.Sound().click.play()
                pygame.quit()
                sys.exit()
        elif menu_game == "menu":
            screen.blit(pygame.image.load("./img_game/titre.png").convert(), (540, 75))
            if play_button.draw(screen):
                class_sound.Sound().click.play()
                exec(open("./project_code/code_game/game.py").read())
            elif settings_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "settings"
            elif quit_button.draw(screen):
                class_sound.Sound().click.play()
                pygame.quit()
                sys.exit()
        # Gère les événements et l'affichage spécifiques au menu principal.
        elif menu_game == "settings":
            if rules_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "rules"
            elif credits_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "help"
            elif hotkeys_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "hotkeys"
            elif back_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "menu"
        elif menu_game == "rules":
            draw_text("The rules of play are very simple: when the bird touches an", (255, 255, 255), 50, 150)
            draw_text("asteroid, a plane, the floor or the ceiling the game is over.", (255, 255, 255), 50, 250)
            draw_text("The player receives a certain number of points for each ", (255, 255, 255), 50, 350)
            draw_text("jump made that the ship avoids.", (255, 255, 255), 50, 450)
            if back_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "settings"
        elif menu_game == "help":
            draw_text("Mathieu ALASSOEUR ", (255, 255, 255), 50, 150)
            draw_text("Samuel DASILVA", (255, 255, 255), 50, 250)
            draw_text("Roland FONTANES ", (255, 255, 255), 50, 350)
            draw_text("Max BORTOLOTTI", (255, 255, 255), 50, 450)
            draw_text("Raphael THEBAULT", (255, 255, 255), 50, 550)
            if back_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "settings"
        elif menu_game == "hotkeys":
            draw_text("The controls of the game are very simple: ", (255, 255, 255), 50, 150)
            draw_text("- The space bar that allows you to jump into the game", (255, 255, 255), 50, 250)
            draw_text("- Esc that allows you to pause the game ", (255, 255, 255), 50, 350)
            draw_text("- Alt + F4 which allows you to close the window", (255, 255, 255), 50, 450)
            if back_button.draw(screen):
                class_sound.Sound().click.play()
                menu_game = "settings"
        # Gère les événements et l'affichage spécifiques au menu des paramètres (du jeu).
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        # Si le bouton de quitter est cliqué, ferme le jeu.

        pygame.display.update()
