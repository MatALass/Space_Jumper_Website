Le projet a été réalisé par Mathieu ALASSOEUR, Samuel DA SILVA, Roland FONTANES, Max BORTOLOTTI, Raphaël THEBAULT.

Pour pouvoir lancer le jeu il faut lancer le fichier main. Bon jeu !