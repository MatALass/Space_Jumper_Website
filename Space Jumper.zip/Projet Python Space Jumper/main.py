# Voici le fichier main que vous devez lancer pour que le jeu se lance.
# ce fichier importe directement la fonction menu qui permettra de lancer le menu

from project_code.code_menu import menu

menu.menu("menu")
